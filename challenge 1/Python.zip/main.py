year = 2023
if (year%4==0):
 print("Leap year")
else:
 print("Not Leap year")
